# -*- coding: utf8 -*-
__author__ = 'zhaofucheng'
import os
from catch import settings
import time

if __name__ == '__main__':
	while True:
		print '开始抓取'
		for name in settings.CATCH_LIST:
			command = 'scrapy crawl %s' % name
			os.system(command)
		print '休眠'
		time.sleep(settings.CATCH_DELAY)

# from twisted.internet import reactor
# from scrapy.crawler import Crawler
# from scrapy import log
# from catch.spiders.guaixun_spider import GuaixunSpider
# from scrapy.utils.project import get_project_settings

# def setup_crawler(domain):
#     spider = GuaixunSpider(domain=domain)
#     settings = get_project_settings()
#     crawler = Crawler(settings)
#     crawler.configure()
#     crawler.crawl(spider)
#     crawler.start()
# while True:
# 	# for domain in settings.CATCH_LIST:
# 	setup_crawler('guaixun')
# 	log.start()
# 	reactor.run()
# 	# time.sleep(3600)