# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import MySQLdb.cursors
from scrapy.exceptions import DropItem
from twisted.enterprise import adbapi
from scrapy import log
import datetime
from catch import settings
import re

import cStringIO, urllib2, Image

class SQLStorePipeline(object):
  
    def __init__(self):
        self.dbpool = adbapi.ConnectionPool('MySQLdb', db=settings.MYSQL_DB,
                user=settings.MYSQL_USER, passwd=settings.MYSQL_PASSWD, cursorclass=MySQLdb.cursors.DictCursor,
                charset='utf8', use_unicode=True)
  
    def process_item(self, item, spider):
        # run db query in thread pool

        if 'play_path' in item:
            query = self.dbpool.runInteraction(self._sound_insert, item)
            query.addErrback(self.handle_error)
        elif 'tag_list' in item:
            query = self.dbpool.runInteraction(self._album_insert, item)
            query.addErrback(self.handle_error)
        elif 'image' in item:
            query = self.dbpool.runInteraction(self._amusing_image_insert, item)
            query.addErrback(self.handle_error)
        return item
    
    def _amusing_image_insert(self, tx, item):
        tx.execute("select * from a_amusing_img where source_url = %s", (item['source_url'][0], ))
        result = tx.fetchone()
        tag = ''
        for x in item['tags']:
            tag += (x + ',')

        if result:
            
            log.msg("Item already stored in db: %s" % item, level=log.DEBUG)
        else:
            # print 'insert into db'
            if 'url' in item:
                file = urllib2.urlopen(item['url'][0])
                tmpIm = cStringIO.StringIO(file.read())
                im = Image.open(tmpIm)

                title=''
                if 'title' in item:
                    for t in item['title']:
                        title += t

                tx.execute(\
                    "insert into a_amusing_img (title,source,source_url,img_url,"
                    "up_vote,down_vote,tags,create_time,width,height,format,release_time) "
                    "values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                    (title,item['source'][0],item['source_url'][0],item['url'][0],item['up_vote'][0],
                        item['down_vote'][0],tag,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        im.size[0],im.size[1],im.format,item['release_time'][0])
                )
            else:
                title=''
                for t in item['title']:
                    title += t
                tx.execute(\
                    "insert into a_amusing_img (title,source,source_url,"
                    "up_vote,down_vote,tags,create_time,release_time) "
                    "values (%s, %s, %s, %s, %s, %s, %s, %s)",
                    (title,item['source'][0],item['source_url'][0],item['up_vote'][0],
                        item['down_vote'][0],tag,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        item['release_time'][0])
                )
            log.msg("Item stored in db: %s" % item, level=log.DEBUG)

    def _album_insert(self, tx, item):
        tx.execute("select * from a_amusing_album where album_id = %s", (item['album_id'][0], ))
        result = tx.fetchone()
        tag = ''
        for x in item['tag_list']:
            tag += (x + ',')

        pattern = re.compile(r'\d*')
        # 使用Pattern匹配文本，获得匹配结果，无法匹配时将返回None
        sound_count = pattern.findall(item['sound_count'][0])[1]

        if result:
            tx.execute(\
                "update a_amusing_album "
                "set album_title = %s, album_source = %s, album_url = %s, "
                "album_img = %s, album_play_count = %s, tag_list = %s, sound_count = %s, "
                "category_name = %s, category_title = %s, update_time = %s "
                "where album_id = %s",
                (item['album_title'][0],item['album_source'][0],item['album_url'][0],item['album_img'][0],
                    item['album_play_count'][0],tag,sound_count,item['category_name'][0],
                    item['category_title'][0],datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),item['album_id'][0])
            )
            log.msg("Item already stored in db: %s" % item, level=log.DEBUG)
        else:
            tx.execute(\
                "insert into a_amusing_album (album_id,album_title,album_source,album_url,"
                "album_img,album_play_count,tag_list,sound_count,category_name,category_title,create_time) "
                "values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (item['album_id'][0],item['album_title'][0],item['album_source'][0],item['album_url'][0],item['album_img'][0],
                    item['album_play_count'][0],tag,sound_count,item['category_name'][0],
                    item['category_title'][0],datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            )
            log.msg("Item stored in db: %s" % item, level=log.DEBUG)

    def _sound_insert(self, tx, item):
        # create record if doesn't exist.
        # all this block run on it's own thread
        tx.execute("select * from a_amusing_audio where id = %s", (item['id'][0], ))
        result = tx.fetchone()
        if result:
			tx.execute(\
                "update a_amusing_audio "
                "set album_id = %s, album_title = %s, category_name = %s,category_title = %s,comments_count = %s,cover_url = %s, "
                "cover_url_142 = %s, duration = %s, favorites_count = %s, formatted_created_at = %s, have_more_intro = %s, "
                "intro = %s, is_favorited = %s, nickname = %s, play_count = %s, play_path = %s, play_path_32 = %s, "
                "play_path_64 = %s, play_path_128 = %s, played_secs = %s, shares_count = %s, short_intro = %s, time_until_now = %s, "
                "title = %s, uid = %s, in_albums = %s, update_time = %s "
                "where id = %s",
                (item['album_id'][0],item['album_title'][0],item['category_name'][0],item['category_title'][0],
                    item['comments_count'][0],item['cover_url'][0],item['cover_url_142'][0],item['duration'][0],
                    item['favorites_count'][0],item['formatted_created_at'][0],item['have_more_intro'][0],
                    item['intro'][0],item['is_favorited'][0],item['nickname'][0],item['play_count'][0],item['play_path'][0],
                    item['play_path_32'][0],item['play_path_64'][0],item['play_path_128'][0],item['played_secs'][0],
                    item['shares_count'][0],item['short_intro'][0],item['time_until_now'][0],item['title'][0],item['uid'][0],
                    item['in_albums'][0],datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),item['id'][0])
            )
			log.msg("Item already stored in db: %s" % item, level=log.DEBUG)
        else:
            tx.execute(\
                "insert into a_amusing_audio (id, album_id,album_title,category_name,category_title,"
                "comments_count,cover_url,cover_url_142,duration,favorites_count,formatted_created_at,"
                "have_more_intro,intro,is_favorited,nickname,play_count,play_path,play_path_32,play_path_64,"
                "play_path_128,played_secs,shares_count,short_intro,time_until_now,title,uid,in_albums,create_time) "
                "values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (item['id'][0],item['album_id'][0],item['album_title'][0],item['category_name'][0],item['category_title'][0],
                    item['comments_count'][0],item['cover_url'][0],item['cover_url_142'][0],item['duration'][0],
                    item['favorites_count'][0],item['formatted_created_at'][0],item['have_more_intro'][0],
                    item['intro'][0],item['is_favorited'][0],item['nickname'][0],item['play_count'][0],item['play_path'][0],
                    item['play_path_32'][0],item['play_path_64'][0],item['play_path_128'][0],item['played_secs'][0],
                    item['shares_count'][0],item['short_intro'][0],item['time_until_now'][0],item['title'][0],item['uid'][0],
                    item['in_albums'][0],datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            )
            log.msg("Item stored in db: %s" % item, level=log.DEBUG)
  
    def handle_error(self, e):
        log.err(e)
