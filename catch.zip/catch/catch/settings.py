# -*- coding: utf-8 -*-

# Scrapy settings for catch project
#
# For simplicity, this file contains only the most important settings by
# default. All the other settings are documented here:
#
#     http://doc.scrapy.org/en/latest/topics/settings.html
#

BOT_NAME = 'catch'

SPIDER_MODULES = ['catch.spiders']
NEWSPIDER_MODULE = 'catch.spiders'

ITEM_PIPELINES = {'catch.pipelines.SQLStorePipeline': 400}
LOG_ENABLED = False

MYSQL_LOCATION = '127.0.0.1'
MYSQL_USER = 'catchuser'
MYSQL_PASSWD = 'zfc33786668'
MYSQL_DB = 'amusingdb'

CATCH_LIST = ['guaixun','ximalaya']
CATCH_DELAY = 3600

# Crawl responsibly by identifying yourself (and your website) on the user-agent
#USER_AGENT = 'catch (+http://www.yourdomain.com)'
