# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.contrib.loader import ItemLoader
from scrapy.contrib.loader.processor import MapCompose, TakeFirst, Join

class imgItem(scrapy.Item):
    title = scrapy.Field()
    url = scrapy.Field()
    source_url = scrapy.Field()
    width = scrapy.Field()
    height = scrapy.Field()
    up_vote = scrapy.Field()
    down_vote = scrapy.Field()
    source = scrapy.Field()
    tags = scrapy.Field()
    release_time = scrapy.Field()
    image = scrapy.Field()

class SoundAlbum(scrapy.Item):
    album_id = scrapy.Field()
    album_title = scrapy.Field()
    album_source = scrapy.Field()
    album_url = scrapy.Field()
    album_img = scrapy.Field()
    album_play_count = scrapy.Field()
    tag_list = scrapy.Field()
    sound_count = scrapy.Field()
    category_name = scrapy.Field()
    category_title = scrapy.Field()

class soundItem(scrapy.Item):
    id = scrapy.Field()
    album_id = scrapy.Field()
    album_title = scrapy.Field()
    category_name = scrapy.Field()
    category_title = scrapy.Field()
    comments_count = scrapy.Field()
    cover_url = scrapy.Field()
    cover_url_142 = scrapy.Field()
    duration = scrapy.Field()
    favorites_count = scrapy.Field()
    formatted_created_at = scrapy.Field()
    have_more_intro = scrapy.Field()
    intro = scrapy.Field()
    is_favorited = scrapy.Field()
    nickname = scrapy.Field()
    play_count = scrapy.Field()
    play_path = scrapy.Field()
    play_path_32 = scrapy.Field()
    play_path_64 = scrapy.Field()
    play_path_128 = scrapy.Field()
    played_secs = scrapy.Field()
    shares_count = scrapy.Field()
    short_intro = scrapy.Field()
    time_until_now = scrapy.Field()
    title = scrapy.Field()
    uid = scrapy.Field()
    in_albums = scrapy.Field()

class MyItemLoader(ItemLoader):
    default_input_processor = MapCompose(lambda s: s.strip())
    default_output_processor = TakeFirst()
    description_out = Join()