# -*- coding: utf-8 -*-
# 怪讯网爬虫
import scrapy
from scrapy.spider import Spider
from scrapy.selector import Selector
from scrapy.contrib.loader import ItemLoader, Identity
from catch.items import imgItem
import re

class GuaixunSpider(scrapy.Spider):
    name = "guaixun"
    allowed_domains = ["guaixun.com"]
    start_urls = [
        "http://www.guaixun.com/"
    ]

    def parse(self, response):
        sel = Selector(response)
        categories = sel.xpath("//div[@class='menu_left']/a/@href").extract()
        if len(categories) > 0:
            for x in xrange(0,2):
                request = scrapy.Request('http://www.guaixun.com%s' % categories[x], callback=self.parse_newest)
                
                yield request

    def parse_newest(self, response):
        sel = Selector(response)
        sites = sel.xpath("//div[@class='cn']").extract()
        for link in sites:
            imgSel = Selector(text=link, type="html")
            imgURL = imgSel.xpath("//div[@class='nr']/a/@href").extract()[0]
            release_time = imgSel.xpath("//div[@class='xiaodian']/text()").extract()[0].strip()
            m = re.match(r'(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})', release_time)
            release_time = m.group()
            request = scrapy.Request('http://www.guaixun.com/%s' % imgURL, callback=lambda response, release_time=release_time: self.parse_item(response,release_time))
            yield request

        pages = sel.xpath("//div[@class='page']/a/@href").extract()
        # print('pages: %s' % pages)
        if len(pages) > 2:
            root_url = 'http://www.guaixun.com/'
            if re.match(r'http://www.guaixun.com/html/\w+.html', response.url):
                root_url = root_url + 'html/'
                page_link = pages[-1]
            else:
                page_link = pages[-2]

            request = scrapy.Request(root_url + page_link, callback=self.parse_newest)
            yield request

    def parse_item(self, response, release_time):
        l = ItemLoader(item=imgItem(), response=response)
        l.add_xpath('title', "//div[@class='nr']/a/p/text()")
        l.add_xpath('url', "//div[@class='nr']/a/p/img/@src", Identity())
        l.add_xpath('width', "//div[@class='nr']/a/p/img/@width")
        l.add_xpath('height', "//div[@class='nr']/a/p/img/@height")
        l.add_xpath('up_vote', "//li[@class='dingx']/a/text()")
        l.add_xpath('down_vote', "//li[@class='caix']/a/text()")
        l.add_xpath('tags', "//div[@class='xiaodian2']/a/text()")
        l.add_value('source_url',response.url)
        l.add_value('release_time',release_time)
        l.add_value('source', u'怪讯网')
        l.add_value('image',u'1')
        return l.load_item()
