# -*- coding: utf-8 -*-
# 我们爱讲冷笑话网爬虫
import scrapy
from scrapy.spider import Spider
from scrapy.selector import Selector
from scrapy.contrib.loader import ItemLoader, Identity
from catch.items import imgItem
import re

class lengxiaohuaSpider(scrapy.Spider):
    name = "lengxiaohua"
    allowed_domains = ["lengxiaohua.com/"]
    start_urls = [
        "http://lengxiaohua.com/"
    ]

    def parse(self, response):
        sel = Selector(response)

        categories = sel.xpath("//div[@class='menu_left']/a/@href").extract()
        if len(categories) > 0:
            for x in xrange(0,1):
                request = scrapy.Request('http://www.guaixun.com%s' % categories[x], callback=self.parse_newest)
                yield request

    def parse_newest(self, response):
        sel = Selector(response)
        sites = sel.xpath("//div[@class='cn']/div[@class='nr']/a/@href").extract()

        for link in sites:
            request = scrapy.Request('http://www.guaixun.com/%s' % link, callback=self.parse_item)
            yield request

        pages = sel.xpath("//div[@class='page']/a/@href").extract()
        print('pages: %s' % pages)
        if len(pages) > 2:
            root_url = 'http://www.guaixun.com/'
            if re.match(r'http://www.guaixun.com/html/\w+.html', response.url):
                root_url = root_url + 'html/'
                page_link = pages[-1]
            else:
                page_link = pages[-2]

            request = scrapy.Request(root_url + page_link, callback=self.parse_newest)
            yield request

    def parse_item(self, response):
        l = ItemLoader(item=imgItem(), response=response)
        l.add_xpath('title', "//div[@class='nr']/a/p/text()")
        l.add_xpath('url', "//div[@class='nr']/a/p/img/@src", Identity())
        l.add_xpath('width', "//div[@class='nr']/a/p/img/@width")
        l.add_xpath('height', "//div[@class='nr']/a/p/img/@height")
        return l.load_item()
