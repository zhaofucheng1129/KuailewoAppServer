# -*- coding: utf-8 -*-
# 喜马拉雅声音爬虫
import scrapy
from scrapy.spider import Spider
from scrapy.selector import Selector
from scrapy.contrib.loader import ItemLoader, Identity
from catch.items import soundItem,SoundAlbum
import json

from twisted.enterprise import adbapi
import MySQLdb as mdb
import sys
from catch import settings

class ximalayaSpider(scrapy.Spider):

    name = "ximalaya"
    allowed_domains = ["ximalaya.com"]
    start_urls = [
        'http://album.ximalaya.com/dq/entertainment/'
    ]

    def parse(self, response):
        sel = Selector(response)
        albums = sel.xpath("//div[@class='discoverAlbum_item']/a[@class='discoverAlbum_title']/@href").extract()
        albumIds = sel.xpath("//div[@class='discoverAlbum_item']/@album_id").extract()
        play_counts = sel.xpath("//div[@class='discoverAlbum_item']/div[@class='albumfaceOutter']/div[@class='playcountOutter']/span[@class='sound_playcount']/text()").extract()
        index = 0
        for album in albums:
            # albumSel = Selector(text=album, type="html")
            # albumUrl = albumSel.xpath("//a[@class='discoverAlbum_title']/@href").extract()
            request = scrapy.Request(album, callback=lambda response, album_id=albumIds[index],play_count=play_counts[index]: self.parse_album(response,album_id,play_count))
            index+=1
            yield request
            
        #读取分页
        pages = sel.xpath("//div[@class='pagingBar_wrapper']/a/@href").extract()
        pageNums = sel.xpath("//div[@class='pagingBar_wrapper']/a/@data-page").extract()
        if len(pages) > 2:
            root_url = 'http://album.ximalaya.com'
            print pageNums[-1]
            if int(pageNums[-1]) <=50:
                page_link = pages[-1]
                request = scrapy.Request(root_url + page_link, callback=self.parse)
                yield request

        #更新数据库中存储的专辑声音
        try:
            con = mdb.connect(settings.MYSQL_LOCATION, settings.MYSQL_USER, settings.MYSQL_PASSWD, settings.MYSQL_DB)
            cur = con.cursor()
            cur.execute("select album_url,album_id from a_amusing_album")
            albums = cur.fetchall()
            if len(albums) > 0:
                for album in albums:
                    # start_urls.append(url[0])
                    request = scrapy.Request(album[0], callback=lambda response, album_id=album[1]: self.parse_album_sound(response,album_id))
                    yield request
        except mdb.Error, e:
            print "Error %d: %s" % (e.args[0],e.args[1])
            sys.exit(1)
        finally:
            if con:    
                con.close()

    #解析专辑
    def parse_album(self,response,album_id,play_count):
        l = ItemLoader(item=SoundAlbum(), response=response)
        l.add_value('album_id', album_id if album_id != None else '')
        l.add_xpath('album_title', "//div[@class='detailContent_title']/h1/text()")
        l.add_value('album_source', u'喜马拉雅')
        l.add_value('album_url', response.url)
        l.add_xpath('album_img', "//div[@class='left']/a/span/img/@popsrc")
        # l.add_xpath('album_play_count', "//div[@class='detailContent_playcountDetail']/span/text()")
        l.add_value('album_play_count', play_count if play_count != None else '')
        l.add_xpath('tag_list', "//div[@class='tagBtnList']/a[@class='tagBtn2']/span/text()")
        l.add_xpath('sound_count', "//div[@class='left']/span[@class='title']/span[@class='albumSoundcount']/text()")
        l.add_value('category_name', u'entertainment')
        l.add_xpath('category_title', "//div[@class='detailContent_category']/a[@rel='nofollow']/text()")
        return l.load_item()

    #解析专辑声音
    def parse_album_sound(self,response,album_id):
        sel = Selector(response)
        sounds = sel.xpath("//div[@class='album_soundlist ']/ul/li/@sound_id").extract()
        for sound in sounds:
            request = scrapy.Request('http://www.ximalaya.com/tracks/%s.json' % sound, callback=lambda response, album_id=album_id: self.parse_sound(response,album_id))
            yield request

        pages = sel.xpath("//div[@class='pagingBar_wrapper']/a/@href").extract()
        if len(pages) > 2:
            root_url = 'http://www.ximalaya.com'
            page_link = pages[-1]
            request = scrapy.Request(root_url + page_link, callback=self.parse)
            yield request

    def parse_sound(self, response, album_id):
        site = json.loads(response.body_as_unicode())
        l = ItemLoader(item=soundItem())
        # l.add_value('source', 'http://fdfs.xmcdn.com/' + sites['play_path'])
        l.add_value('id', site['id'] if site['id'] != None else '')
        l.add_value('album_id', site['album_id'] if site['album_id'] != None else '')
        l.add_value('album_title', site['album_title'] if site['album_title'] != None else '')
        l.add_value('category_name', site['category_name'] if site['category_name'] != None else '')
        l.add_value('category_title', site['category_title'] if site['category_title'] != None else '')
        l.add_value('comments_count', site['comments_count'] if site['comments_count'] != None else '')
        l.add_value('cover_url', site['cover_url'] if site['cover_url'] != None else '')
        l.add_value('cover_url_142', site['cover_url_142'] if site['cover_url_142'] != None else '')
        l.add_value('duration', site['duration'] if site['duration'] != None else '')
        l.add_value('favorites_count', site['favorites_count'] if site['favorites_count'] != None else '')
        l.add_value('formatted_created_at', site['formatted_created_at'] if site['formatted_created_at'] != None else '')
        l.add_value('have_more_intro', site['have_more_intro'] if site['have_more_intro'] != None else '')
        l.add_value('intro', site['intro'] if site['intro'] != None else '')
        l.add_value('is_favorited', site['is_favorited'] if site['is_favorited'] != None else '')
        l.add_value('nickname', site['nickname'] if site['nickname'] != None else '')
        l.add_value('play_count', site['play_count'] if site['play_count'] != None else '')
        l.add_value('play_path', 'http://fdfs.xmcdn.com/'+site['play_path'] if site['play_path']!=None else '')
        l.add_value('play_path_32', 'http://fdfs.xmcdn.com/'+site['play_path_32'] if site['play_path_32']!=None else '')
        l.add_value('play_path_64', 'http://fdfs.xmcdn.com/'+site['play_path_64'] if site['play_path_64']!=None else '')
        l.add_value('play_path_128', 'http://fdfs.xmcdn.com/'+site['play_path_128'] if site['play_path_128']!=None else '')
        l.add_value('played_secs', site['played_secs'] if site['played_secs'] != None else '')
        l.add_value('shares_count', site['shares_count'] if site['shares_count'] != None else '')
        l.add_value('short_intro', site['short_intro'] if site['short_intro'] != None else '')
        l.add_value('time_until_now', site['time_until_now'] if site['time_until_now'] != None else '')
        l.add_value('title', site['title'] if site['title'] != None else '')
        l.add_value('uid', site['uid'] if site['uid'] != None else '')
        l.add_value('in_albums',album_id if album_id != None else '')
        return l.load_item()